package com.socketservlet;


import com.staticPacket.ReloadFile;


import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Properties;

public class SocketGetLog extends Thread {

    @Override
    public void run() {
        Properties properties = ReloadFile.properties;
        try {

            System.out.println("进来了");
            int port = Integer.parseInt((String) properties.get("server_port"));

            ServerSocket ss = new ServerSocket(port);



            while (true) {


                Socket socket;
                if ((socket = ss.accept()) != null) {
                    System.out.println("接受到了" + socket);
                    Socket socketUsing = socket;
                    System.out.println("开启新的线程处理别的事情");
                    SocketThread socketThread = new SocketThread(socketUsing);


                    Thread thread2 = new Thread(socketThread);
                    System.out.println("开始新的线程");
                    thread2.start();
                    System.out.println("已经开始新的线程");
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}