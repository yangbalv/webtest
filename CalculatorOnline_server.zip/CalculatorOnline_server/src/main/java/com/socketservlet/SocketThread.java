package com.socketservlet;

import com.alibaba.fastjson.JSONObject;
import com.dto.LoginLogs;
import com.dto.SocketRemoteDto;
import com.dto.StaticLogs;

import java.io.DataInputStream;

import java.io.DataOutputStream;

import java.io.IOException;

import java.io.InputStream;

import java.io.OutputStream;

import java.net.Socket;

/*处理socket

 * 处理数据的读和写的操作*/

public class SocketThread implements Runnable {

    private Socket socket;

//构造方法中的socket就是使用这个socketThread类对象的时候传递过来给他的

    public SocketThread(Socket socket) {
        this.socket = socket;

    }


    public void run() {

        System.out.println("进入到新的线程");
//        boolean change = TestMessage.getChange();
        while (true) {
            try {
//            System.out.println("change");
                if (StaticLogs.loginChange) {
                    System.out.println("用户登录了");
                    System.out.println(StaticLogs.finalOperational);

//                System.out.println(i);
                    try {
                        LoginLogs loginLogs = new LoginLogs();
                        loginLogs.setAllMessage(StaticLogs.allMessage);
                        loginLogs.setChange(StaticLogs.loginChange);
                        loginLogs.setMessage(StaticLogs.message);

                        InputStream in;
                        in = socket.getInputStream();
                        DataInputStream dis = new DataInputStream(in);
                        String str = dis.readUTF();

                        OutputStream out = socket.getOutputStream();
                        DataOutputStream dos = new DataOutputStream(out);

                        dos.writeUTF(JSONObject.toJSONString(loginLogs));
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
//                    Thread.sleep(2);
                    if (StaticLogs.loginChange) {
                        StaticLogs.loginChange = false;
                    }
                }
                if (StaticLogs.operationChange) {

//                    System.out.println("触发了事件");
//                    System.out.println(StaticLogs.finalOperational);

//                System.out.println(i);
                    try {
                        SocketRemoteDto socketResponseDto = new SocketRemoteDto();
//                        socketResponseDto.setAllMessage(new String(StaticLogs.allMessage));
                        socketResponseDto.setMessage(StaticLogs.message);


                        socketResponseDto.setOperational(new String(StaticLogs.operational));
                        socketResponseDto.setFinalOperational(new String(StaticLogs.finalOperational));
                        socketResponseDto.setResult(StaticLogs.result);
                        socketResponseDto.setDate(StaticLogs.date);
                        socketResponseDto.setUsername(StaticLogs.user.getUsername());


                        InputStream in;
                        in = socket.getInputStream();
                        DataInputStream dis = new DataInputStream(in);
                        String str = dis.readUTF();

                        OutputStream out = socket.getOutputStream();
                        DataOutputStream dos = new DataOutputStream(out);

                        dos.writeUTF(JSONObject.toJSONString(socketResponseDto));
//                        Thread.sleep(2);

                        if (StaticLogs.operationChange) {
                            StaticLogs.operationChange = false;
                        }

                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }


            } catch (Exception e) {
                e.printStackTrace();
            }
        }


    }

    @Override
    protected void finalize() throws Throwable {
        System.out.println("当前线程被删除----");
        super.finalize();
    }
}