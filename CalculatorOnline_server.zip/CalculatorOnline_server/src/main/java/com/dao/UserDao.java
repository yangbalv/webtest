package com.dao;

import com.entity.User;

public interface UserDao {
    boolean add(User user);

    User findById(int id);

    User findByName(String name);

}
