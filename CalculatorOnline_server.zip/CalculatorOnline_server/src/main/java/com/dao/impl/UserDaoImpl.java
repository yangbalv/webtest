package com.dao.impl;

import com.dao.UserDao;
import com.entity.User;
import com.util.MybatisUtils;
import org.apache.ibatis.session.SqlSession;

public class UserDaoImpl implements UserDao {

    @Override
    public boolean add(User user) {
        try (SqlSession sqlSession = MybatisUtils.getSqlSession(true)) {

            return sqlSession.getMapper(UserDao.class).add(user);
        } catch (RuntimeException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public User findById(int id) {
        try (SqlSession sqlSession = MybatisUtils.getSqlSession(true)) {
            return sqlSession.getMapper(UserDao.class).findById(id);
        } catch (RuntimeException e) {
           e.printStackTrace();
        }
        return null;
    }

    @Override
    public User findByName(String name) {
        try (SqlSession sqlSession = MybatisUtils.getSqlSession(true)) {
            return sqlSession.getMapper(UserDao.class).findByName(name);
        } catch (RuntimeException e) {
            e.printStackTrace();
        }
        return null;
    }


    public Boolean login(User user) {
        System.out.println("((((((((((((((((((((");
        try (SqlSession sqlSession = MybatisUtils.getSqlSession(true)) {
            User getUser = sqlSession.getMapper(UserDao.class).findByName(user.getName());
            if (null != getUser) {
                if (getUser.getPassword().equals(user.getPassword())) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }

        } catch (RuntimeException e) {
            e.printStackTrace();
        }
        return false;
    }

    public static void main(String[] args) {
        UserDaoImpl newUserDao = new UserDaoImpl();
        User user = new User();
        user.setName("23");
        user.setPassword("24");
//        newUserDao.add(user);
//        User user = newUserDao.findByName("11");
        System.out.println(newUserDao.login(user));
    }


}
