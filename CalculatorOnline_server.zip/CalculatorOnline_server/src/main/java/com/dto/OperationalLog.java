package com.dto;

import com.alibaba.fastjson.JSONObject;

public class OperationalLog {
    private String finalOperational;
    private String result;
    private String operational;

    public String getFinalOperational() {
        return finalOperational;
    }

    public void setFinalOperational(String finalOperational) {
        this.finalOperational = finalOperational;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getOperational() {
        return operational;
    }

    public void setOperational(String operational) {
        this.operational = operational;
    }

    public static void main(String[] args) {
        OperationalLog operationalLog = new OperationalLog();
        operationalLog.setFinalOperational("111111");
        operationalLog.setResult("2222222");
        operationalLog.setOperational("3333333");
        System.out.println(JSONObject.toJSONString(operationalLog));
    }
}
