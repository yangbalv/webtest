package com.dto;

import com.entity.User;

import java.util.Date;

public class SocketRemoteDto {
    private String username;
    private Date date;
    private volatile String allMessage;
    private volatile String message;
    private volatile String finalOperational;
    private volatile String result;
    private volatile String operational;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getAllMessage() {
        return allMessage;
    }

    public void setAllMessage(String allMessage) {
        this.allMessage = allMessage;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getFinalOperational() {
        return finalOperational;
    }

    public void setFinalOperational(String finalOperational) {
        this.finalOperational = finalOperational;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getOperational() {
        return operational;
    }

    public void setOperational(String operational) {
        this.operational = operational;
    }
}
