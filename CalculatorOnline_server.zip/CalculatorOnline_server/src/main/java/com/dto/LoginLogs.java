package com.dto;

public class LoginLogs {
    private boolean change;
    private StringBuffer allMessage;
    private String message;

    public boolean isChange() {
        return change;
    }

    public void setChange(boolean change) {
        this.change = change;
    }

    public StringBuffer getAllMessage() {
        return allMessage;
    }

    public void setAllMessage(StringBuffer allMessage) {
        this.allMessage = allMessage;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
