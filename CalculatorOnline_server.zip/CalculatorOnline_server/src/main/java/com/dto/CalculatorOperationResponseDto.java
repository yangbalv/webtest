package com.dto;

import com.alibaba.fastjson.JSON;

public class CalculatorOperationResponseDto {


    public CalculatorOperationResponseDto() {
    }

    public static CalculatorOperationResponseDto reload(String message) {
        CalculatorOperationResponseDto responseDto = new CalculatorOperationResponseDto();
        responseDto = JSON.toJavaObject(JSON.parseObject(message), CalculatorOperationResponseDto.class);
        return responseDto;
    }


}
