package com.dto;

import com.entity.User;

import java.util.Date;

public class StaticLogs {
    public static volatile boolean loginChange;
    public static volatile boolean read;
    public static volatile StringBuffer allMessage;
    public static volatile String message;

    public static volatile boolean operationChange;
    public static volatile StringBuffer finalOperational;
    public static volatile String result;
    public static volatile StringBuffer operational;

    public static volatile User user;
    public static volatile Date date;

    static {
        loginChange = false;
        read = false;
        allMessage = new StringBuffer();
        message = "";
        operationChange = false;
        finalOperational = new StringBuffer();
        result = "";
        operational = new StringBuffer();
        user = new User();
        date = new Date();
    }
}
