package com.servlet.user;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.dto.CalculatorOperationRequestDto;
import com.dto.StaticLogs;
import com.servlet.result.ResultDto;
import com.util.CountService;
import com.util.HttpTool;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class AcceptOperationKey extends HttpServlet {
    static Set operation = new HashSet();
    static boolean beforeIsNotNumber;
    static boolean nowIsEmpty;

    static {

        operation.add("+");
        operation.add("-");
        operation.add("*");
        operation.add("/");
        beforeIsNotNumber = true;
        nowIsEmpty = true;
    }


    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) {
        ResultDto resultDto = new ResultDto();

        try {
            if (!StaticLogs.operationChange) {

                InputStream inputStream = req.getInputStream();

                String body = HttpTool.getReqBody(inputStream);


                CalculatorOperationRequestDto requestDto = JSON.toJavaObject(JSON.parseObject(body), CalculatorOperationRequestDto.class);

                String message = "时间: -----" + requestDto.getDate() + "----\n 用户: " + requestDto.getUser().getName() + "按下了（" + requestDto.getKey() + ")";


                if (requestDto.getKey().equals("=")) {
                    System.out.println("等于号");
                    if (!beforeIsNotNumber) {
                        if (!nowIsEmpty) {
                            System.out.println("处理结果");
                            try {
                                String res = CountService.analysis(new String(StaticLogs.finalOperational));
                                StaticLogs.result = res;

                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            resultDto.setSuccess(true);
                            beforeIsNotNumber = true;
                            nowIsEmpty = true;
                        }
                    } else {
                        resultDto.setSuccess(false);
                        resultDto.setMessage("当前运算式无法算出结果");
                        message += "\nwarning:当前运算式无法算出结果";
                    }
                } else if (operation.contains(requestDto.getKey())) {
                    System.out.println("运算符");

                    if (!nowIsEmpty) {

                        if (!beforeIsNotNumber) {

                            StaticLogs.operational = new StringBuffer(requestDto.getKey());
                            StaticLogs.finalOperational.append(requestDto.getKey());
                            resultDto.setSuccess(true);
                            beforeIsNotNumber = true;

                        } else {

                            resultDto.setSuccess(false);
                            resultDto.setMessage("当前运算不能进行，不能在运算符 " + StaticLogs.operational + " 后面直接使用 " + requestDto.getKey() + " 。");
                            message += "\n当前运算不能进行，不能在运算符 " + StaticLogs.operational + " 后面直接使用 " + requestDto.getKey() + " 。";
                        }


                    } else {
                        if (!"-".equals(requestDto.getKey())) {
                            StaticLogs.finalOperational.append(requestDto.getKey());
                            beforeIsNotNumber = true;
                            StaticLogs.operational = new StringBuffer(requestDto.getKey());
                            resultDto.setSuccess(true);
                        }
                    }

                } else {
                    if (beforeIsNotNumber) {
                        System.out.println("数字");
                        System.out.println("重置数据");
                        StaticLogs.operational = new StringBuffer(requestDto.getKey());
                        resultDto.setSuccess(true);
                        beforeIsNotNumber = false;
                        if (nowIsEmpty) {
                            StaticLogs.finalOperational = new StringBuffer();
                            nowIsEmpty = false;
                        }
                    } else {
                        System.out.println("前一个数是数字");
                        StaticLogs.operational.append(requestDto.getKey());
                        resultDto.setSuccess(true);
                    }


                    StaticLogs.finalOperational.append(requestDto.getKey());
//                    StaticLogs.result = new String(StaticLogs.finalOperational);

                    nowIsEmpty = false;

                }
                StaticLogs.message = message;
                StaticLogs.allMessage.append(message);

                String response = JSONObject.toJSONString(resultDto);
                OutputStream out = resp.getOutputStream();
                out.write(response.getBytes(StandardCharsets.UTF_8));
                StaticLogs.operationChange = true;
//                StaticLogs.operationChange = false;
            } else {
                resultDto.setSuccess(false);
                resultDto.setMessage("有用户真正操作");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}
