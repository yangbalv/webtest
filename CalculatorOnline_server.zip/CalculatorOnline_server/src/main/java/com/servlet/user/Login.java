package com.servlet.user;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.dao.impl.UserDaoImpl;
import com.entity.User;
import com.servlet.result.ResultDto;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServlet;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class Login extends HttpServlet {
    static UserDaoImpl userDaoService;

    static {
        userDaoService = new UserDaoImpl();
        System.out.println("初始化");
    }

    @Override
    public void service(ServletRequest req, ServletResponse res) throws IOException {
        ResultDto resultDto = new ResultDto();
        System.out.println("__________分割线__________");
        BufferedReader reader = new BufferedReader(new InputStreamReader(req.getInputStream(), StandardCharsets.UTF_8));
        Scanner scanner = new Scanner(reader);
        StringBuffer stringBuffer = new StringBuffer();
        while (scanner.hasNextLine()) {
            stringBuffer.append(scanner.nextLine());
        }
        System.out.println("请求的body的原始数据: " + stringBuffer);

        String request = new String(stringBuffer);
        User user = JSON.toJavaObject(JSON.parseObject(request), User.class);

        System.out.println(user);

        User user1 = userDaoService.findByName(user.getName());
//        if (null != user1) {
//
//            if (user1.getPassword().equals(user.getPassword())) {
//                resultDto.setSuccess(true);
//                resultDto.setMessage("登录成功");
//            } else {
//                resultDto.setSuccess(false);
//                resultDto.setMessage("密码不正确");
//            }
//        } else {
//            resultDto.setSuccess(false);
//            resultDto.setMessage("用户不存在或未注册");
//
//        }
        resultDto.setSuccess(true);
        resultDto.setMessage("登录成功");
        String response = JSONObject.toJSONString(resultDto);
        OutputStream out = res.getOutputStream();
        out.write(response.getBytes(StandardCharsets.UTF_8));
    }
}
