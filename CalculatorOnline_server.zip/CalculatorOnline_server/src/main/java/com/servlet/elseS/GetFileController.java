package com.servlet.elseS;

import sun.misc.BASE64Encoder;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.URLEncoder;

public class GetFileController extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        // 获取要下载的文件名称
        String filename = "filename.filetype";

        //如果中文有问题的话，使用下面的代码，修改编码格式
        filename = new String(filename.getBytes("ISO8859-1"), "UTF-8");
        //======================= 根据浏览器的不同，进行不同的编码 =======================
//        获得请求头中的User-Agent
        String agent = request.getHeader("User-Agent");
        //根据不同浏览器进行不同的编码
        String filenameEncoder = "";
//        if (agent.contains("MSIE")) {
//            // IE浏览器
//            filenameEncoder = URLEncoder.encode(filename, "utf-8");
//            filenameEncoder = filenameEncoder.replace("+", " ");
//        } else if (agent.contains("Firefox")) {
//            // 火狐浏览器
//            BASE64Encoder base64Encoder = new BASE64Encoder();
//            filenameEncoder = "=?utf-8?B?"
//                    + base64Encoder.encode(filename.getBytes("utf-8")) + "?=";
//        } else {
//            // 其它浏览器
        filenameEncoder = URLEncoder.encode(filename, "utf-8");
//        }
        // 设置下载的这个文件的类型-----客户端通过文件的MIME类型去区分类型
        response.setContentType(this.getServletContext().getMimeType(filename));
        System.out.println(this.getServletContext().getMimeType(filename));
        // 设置请求头，告诉客户端该文件不是直接解析，而是以附件形式打开(下载）================== 设置响应头的文件名为编码后的名字
        response.setHeader("Content-Disposition", "attachment;filename=" + filenameEncoder);

        // 获取文件的绝对路径
        String path = "D:\\test.xls";
        // 实例化文件输入流
        InputStream in = new FileInputStream(path);
        // 获取文件输出流
        OutputStream out = response.getOutputStream();

        // 实例化字节数组
        byte[] b = new byte[1024];
        int len = 0;
        while ((len = in.read(b)) != -1) {
            out.write(b, 0, len);
        }
        in.close();     // 关闭输入流

    }
}
