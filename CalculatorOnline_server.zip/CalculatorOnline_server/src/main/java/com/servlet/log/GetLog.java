package com.servlet.log;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

public class GetLog extends HttpServlet {
    public static boolean change = false;
    public static String message;

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) {
        if (change) {
            System.out.println("开始发送");
            try {
                System.out.println(message);
                resp.getWriter().write(message);

            } catch (IOException e) {
                e.printStackTrace();
            }
            change = false;
            message = "";
        } else {
            Thread thread = new Thread() {
                @Override
                public void run() {
                    while (true) {

                        while (GetLog.change) {
                            try {
                                resp.getWriter().write(GetLog.message);
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                            break;
                        }

                    }
                }
            };
            thread.start();
        }

    }
}
