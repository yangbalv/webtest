package com.util;

import java.math.BigDecimal;
import java.util.*;

public class CountService {
    private int a;

    public void setA(int a) {
        this.a = a;
    }

    public int getA() {
        return a;
    }

    public static void main(String[] args) {
        CountService countService = new CountService();


        String num = "(1";
//        String result = countService.analysis(num);
        String result = num;

        System.out.println("result is :" + result);
        int x = 20;
        while (true) {
            System.out.println("num1 is :" + num);
            try {
                x = Integer.parseInt(num);
                break;
            } catch (Exception e) {
                System.out.println("这个数据有问题");
                num = num.substring(1);
                System.out.println("num2 is :" + num);
            }
        }
//        while (countService.brackets(num) && num.length() > 1) {
//            num = num.substring(1, num.length() - 1);
//        }
//
//        System.out.println(num);

        System.out.println(x);


    }


    static Set sign1 = new HashSet();
    static Set sign2 = new HashSet();
    static Set operation1 = new HashSet();
    static Set operation2 = new HashSet();
    static Map<Character, Character> operationMap = new HashMap();
    static Map<Character, Integer> map = new HashMap();


    static {
        sign1.add('(');
        sign1.add('[');
        sign1.add('{');

        sign2.add(')');
        sign2.add(']');
        sign2.add('}');

        operationMap.put('(', ')');
        operationMap.put('{', '}');
        operationMap.put('[', ']');


        operation1.add('+');
        operation1.add('-');
        operation2.add('*');
        operation2.add('/');

        map.put('+', 1);
        map.put('-', 2);
        map.put('*', 3);
        map.put('/', 4);
    }

    public static String analysis(String num) throws CountException {
//        System.out.println(" num is : " + num);
//        StringBuffer stringBuffer1 = new StringBuffer();
//        StringBuffer stringBuffer2 = new StringBuffer();

//        //去除整体括号 (1-1)-> 1-1
//        if (num.charAt(0) == '(' && num.charAt(num.length() - 1) == ')') {
//            num = num.substring(1, num.length() - 1);
//        }

//       去除整体括号 (1-1)-> 1-1  新
//        while 是为了多个重复的无用外括号
//        brackets是检测是否含有无用外括号的

        while (brackets(num) && num.length() > 1) {
            num = num.substring(1, num.length() - 1);
        }

        if (num.charAt(0) == '-' || num.charAt(0) == '+') {
            System.out.println("单字符数据：" + num);
//            return num;
        }

        int op = 100;
        Stack<Character> stack = new Stack<Character>();

//        int i = brackets(num);
//        while (i == -1) {
//            num = num.substring(1, num.length() - 1);
//        }
//        i = brackets(num);


        int i;
        int frist = -1;

        List<Character> integerList = new ArrayList<>();

        int side = -1;
        if (null != num) {


            for (i = 0; i < num.length(); i++) {
//                System.out.println(num.charAt(i));
                if (sign1.contains(num.charAt(i))) {
                    stack.push(num.charAt(i));
//                    记录最近的左括号的位置
                    side = i;
                } else if (sign2.contains(num.charAt(i))) {

                    if (stack.size() != 0 && num.charAt(i) == operationMap.get(stack.peek()))
                        stack.pop();
                    else {
                        System.out.println("num.charAt(i) is :" + num.charAt(i) + "stack.peek()" + stack.peek());
                        System.out.println("出栈产生错误：空栈不能出栈");
                        throw new CountException("括号数据不正确");
//                        return null;
                    }
                } else if (operation1.contains(num.charAt(i))) {

                    //
                    if (stack.size() == 0) {
//                    由于前面加了判断所以当前必为空栈
//                    符号不是（-1）这个形式出现的
                        if (i - side != 1) {
                            System.out.println("i - side is :" + (i - side));
                            //无括号
                            if (frist == -1) {
                                frist = i;
                            }
//                        获取运算符
                            op = map.get(num.charAt(i));

                            //将当前的运算符保存下来
                            integerList.add(num.charAt(i));
                            System.out.println("integerList: " + integerList);
                            if (integerList.size() > 1) {
                                if (operation2.contains(integerList.get(integerList.size() - 2))) {
                                    System.out.println("part 1: " + num.substring(0, i) + ", part 2 " + num.substring(i + 1));
                                    break;
                                }
                            }
                        }

                    }
                } else if (operation2.contains(num.charAt(i))) {
                    if (stack.size() == 0) {
                        //无括号
                        if (frist == -1) {
                            frist = i;
                        }
                        op = map.get(num.charAt(i));
                        integerList.add(num.charAt(i));
//                        integerList.add(op);
                    }
                }
            }
//            System.out.println(" num is : " + num + ", and i is : " + i);
            if (op == 100 || frist == 0) {
//                System.out.println("单字符数据：" + num);
                return num;
            } else {
//               System.out.println(analysis(num.substring(0, i))+
//                        op+
//                        analysis(num.substring(i + 1, num.length() - 1)));
                if (i != num.length()) {
                    String result = count(
                            analysis(
                                    num.substring(0, i)),
                            op,
                            analysis(num.substring(i + 1, num.length())));
                    System.out.println("result is : " + result);
                    return result;
                } else {
                    String result = count(
                            analysis(
                                    num.substring(0, frist)),
                            map.get(num.charAt(frist)),
                            analysis(num.substring(frist + 1, num.length())));
                    System.out.println("result is : " + result);
                    return result;
                }
            }

        } else {
            System.out.println("num is null");
        }

        return num;

//        System.out.println(num);
//        int count = 0;
//        boolean nonOperation = true;、
//        StringBuffer num1 = null;
//        StringBuffer num2 = null;
//        int start = 0;
//        int end = start;
//
//        if (null != num) {
//            for (int i = 0; i < num.length(); i++) {
//                if (num.charAt(i) == '(') {
//                    count++;
//                } else if (num.charAt(i) == ')') {
//                    if (i == num.length() - 1) {
//
//                    }
//                    count--;
//
//                } else if (operation.contains(num.charAt(i))) {
//
//                } else {
//                    if (null == num1) {
//                        num1 = new StringBuffer(num.charAt(i));
//                    } else {
//                        num1.append(num.charAt(i));
//                    }
//
//                }
//
//
//            }
//        }
//        String result = new String("result is : ");
//
//        return result;
    }

    public static String count(String num1, int operation, String num2) {
//        System.out.println("num1 is :" + num1 + "num2 is: " + num2);
        BigDecimal bigDecimal1 = new BigDecimal(num1);
        BigDecimal bigDecimal2 = new BigDecimal(num2);
        System.out.println("num1: " + num1 + ", num2: " + num2 + ", operation is: " + operation);
        switch (operation) {
            case 1:
                return String.valueOf(bigDecimal1.add(bigDecimal2));
            case 2:
                return String.valueOf(bigDecimal1.subtract(bigDecimal2));
            case 3:
                return String.valueOf(bigDecimal1.multiply(bigDecimal2));
            case 4:
                return String.valueOf(bigDecimal1.divide(bigDecimal2, 20, BigDecimal.ROUND_CEILING));
            default:
                return "error input";
        }
    }


    //    public double count(double num1, int operation, double num2) {
//        switch (operation) {
//            case 1:
//                return num1 + num2;
//            case 2:
//                return num1 - num2;
//            case 3:
//                return num1 * num2;
//            case 4:
//                return num1 / num2;
//            default:
//                return 0;
//        }
//    }
//
//    public static void main(String[] args) {
//        CountService countService = new CountService();
//        double num1 = 1.5;
//        double num2 = 2.2;
//        String num3 = "111111111111111111111111111111111111111111111111111111";
//        String num4 = "12";
//
//        Map<Character, Integer> map = new HashMap();
//        map.put('+', 1);
//        map.put('-', 2);
//        map.put('*', 3);
//        map.put('/', 4);
//        char operation = '/';
//        System.out.println(countService.count(num1, map.get(operation), num2));
//        System.out.println(countService.count(num3, map.get(operation), num4));
//    }
    //    public double resolve(String combination) {
//        Stack stack = new Stack();
//        StringBuffer sb = new StringBuffer(combination);
//        for (int i = 0; i < sb.length(); i++) {
//            if (sb.charAt(i)=='('){
//                stack.push(sb.charAt(i));
//
//            }
//        }
//
//    }
    public static boolean brackets(String num) {
        final int firstP;
        int lastP;

        Stack stack = new Stack();
        boolean hhont = false;

        int i;
        for (i = 0; i < num.length(); i++) {


            if (sign1.contains(num.charAt(i))) {
                stack.push(num.charAt(i));
                hhont = true;
            } else if (sign2.contains(num.charAt(i))) {
                if (stack.size() != 0) {
                    stack.pop();
                } else {
                    System.out.println("请检查输入的表达式，表达式是否存在括号异常");
                }
            } else if ((operation1.contains(num.charAt(i)) || operation2.contains(num.charAt(i))) && i != 0) {
                if (stack.size() == 0) {
                    //满足条件说明包涵有用的运算符说明不需要拆括号
//                    hOperation = true;
                    break;
                }
            }
        }
        if (i == num.length()) {
            if (hhont) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }
}
