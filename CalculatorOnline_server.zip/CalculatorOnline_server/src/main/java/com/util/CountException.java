package com.util;

public class CountException extends Exception {

    private String message;

    public CountException(String message) {
        this.message = message;
    }
    public CountException() {
    }
}
