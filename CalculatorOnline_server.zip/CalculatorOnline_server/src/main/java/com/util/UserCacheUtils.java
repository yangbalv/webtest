package com.util;

import com.socketservlet.SocketGetLog;
import com.staticPacket.ReloadFile;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

public class UserCacheUtils implements ServletContextListener {


    @Override
    public void contextInitialized(ServletContextEvent sce) {
        System.out.println("启动");
        new ReloadFile();
        new SocketGetLog().start();
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        System.out.println("关闭");
    }

}