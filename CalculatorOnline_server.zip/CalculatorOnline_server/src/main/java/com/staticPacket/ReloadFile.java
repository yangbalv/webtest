package com.staticPacket;

import org.springframework.context.annotation.PropertySource;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class ReloadFile {
    public static Properties properties;

    static {
        properties = new Properties();
        File file = new File("src/main/resources/properties/test.properties");
        try {
            properties.load(new FileInputStream(file.getAbsolutePath()));
        } catch (IOException e) {
            e.printStackTrace();
        }


    }



}
