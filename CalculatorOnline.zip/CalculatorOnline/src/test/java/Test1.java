import com.static_class.ReloadFile;
import com.utils.HttpHelper;
import org.junit.Test;

public class Test1 {


    public static void main(String[] args) {
        new ReloadFile();
        String path = (String) ReloadFile.properties.get("server_path");
        String msg = HttpHelper.getHelper(path + "/CalculatorOnline_server_war_exploded/userController/getLog");
        System.out.println(msg);
    }
}
