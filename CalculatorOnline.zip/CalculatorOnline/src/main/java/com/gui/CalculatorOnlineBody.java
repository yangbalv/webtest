package com.gui;

import com.alibaba.fastjson.JSONObject;
import com.dto.CalculatorOperationRequestDto;
import com.dto.CalculatorOperationResponseDto;
import com.entity.User;
import com.socketPost.Client;
import com.static_class.ReloadFile;
import com.utils.HttpHelper;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;
import java.util.Properties;

public class CalculatorOnlineBody extends JFrame {

    public static JPanel body, operationMessage, logMessage;
    public static JButton num1, num2, num3, num4, num5, num6, num7, num8, num9, num0, operationAdd, operationReduce, operationRide, operationExcept, spot, result;
    public static JTextArea logsStart, data, temporaryData, res, logs;
    public static JScrollPane jScrollPane;

    public  User user;
    public static CalculatorOperationRequestDto requestDto = new CalculatorOperationRequestDto();

     {
        requestDto.setDate(new Date());
        requestDto.setUser(this.user);
        new ReloadFile();
        String path = (String) ReloadFile.properties.get("server_path");


        num1 = new JButton("1");
        num1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Thread thread = new Thread() {
                    @Override
                    public void run() {
                        requestDto.setKey(num1.getText());
                        String result = HttpHelper.postHelper(path + "/CalculatorOnline_server_war_exploded/userController/acceptOperationKey", JSONObject.toJSONString(requestDto));
                        System.out.println(result);
                    }
                };
                thread.start();
            }
        });


        num2 = new JButton("2");
        num2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Thread thread = new Thread() {
                    @Override
                    public void run() {
                        requestDto.setKey(num2.getText());
                        String result = HttpHelper.postHelper(path + "/CalculatorOnline_server_war_exploded/userController/acceptOperationKey", JSONObject.toJSONString(requestDto));
                        System.out.println(result);
                    }
                };
                thread.start();
            }
        });
        num3 = new JButton("3");
        num3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Thread thread = new Thread() {
                    @Override
                    public void run() {
                        requestDto.setKey(num3.getText());
                        String result = HttpHelper.postHelper(path + "/CalculatorOnline_server_war_exploded/userController/acceptOperationKey", JSONObject.toJSONString(requestDto));
                        System.out.println(result);
                    }
                };
                thread.start();
            }
        });
        num4 = new JButton("4");
        num4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Thread thread = new Thread() {
                    @Override
                    public void run() {
                        requestDto.setKey(num4.getText());
                        String result = HttpHelper.postHelper(path + "/CalculatorOnline_server_war_exploded/userController/acceptOperationKey", JSONObject.toJSONString(requestDto));
                        System.out.println(result);
                    }
                };
                thread.start();
            }
        });
        num5 = new JButton("5");
        num5.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Thread thread = new Thread() {
                    @Override
                    public void run() {
                        requestDto.setKey(num5.getText());
                        String result = HttpHelper.postHelper(path + "/CalculatorOnline_server_war_exploded/userController/acceptOperationKey", JSONObject.toJSONString(requestDto));
                        System.out.println(result);
                    }
                };
                thread.start();
            }
        });
        num6 = new JButton("6");
        num6.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Thread thread = new Thread() {
                    @Override
                    public void run() {
                        requestDto.setKey(num6.getText());
                        String result = HttpHelper.postHelper(path + "/CalculatorOnline_server_war_exploded/userController/acceptOperationKey", JSONObject.toJSONString(requestDto));
                        System.out.println(result);
                    }
                };
                thread.start();
            }
        });
        num7 = new JButton("7");
        num7.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Thread thread = new Thread() {
                    @Override
                    public void run() {
                        requestDto.setKey(num7.getText());
                        String result = HttpHelper.postHelper(path + "/CalculatorOnline_server_war_exploded/userController/acceptOperationKey", JSONObject.toJSONString(requestDto));
                        System.out.println(result);
                    }
                };
                thread.start();
            }
        });
        num8 = new JButton("8");
        num8.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Thread thread = new Thread() {
                    @Override
                    public void run() {
                        requestDto.setKey(num8.getText());
                        String result = HttpHelper.postHelper(path + "/CalculatorOnline_server_war_exploded/userController/acceptOperationKey", JSONObject.toJSONString(requestDto));
                        System.out.println(result);
                    }
                };
                thread.start();
            }
        });
        num9 = new JButton("9");
        num9.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Thread thread = new Thread() {
                    @Override
                    public void run() {
                        requestDto.setKey(num9.getText());
                        String result = HttpHelper.postHelper(path + "/CalculatorOnline_server_war_exploded/userController/acceptOperationKey", JSONObject.toJSONString(requestDto));
                        System.out.println(result);
                    }
                };
                thread.start();
            }
        });
        num0 = new JButton("0");
        num0.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Thread thread = new Thread() {
                    @Override
                    public void run() {
                        requestDto.setKey(num0.getText());
                        String result = HttpHelper.postHelper(path + "/CalculatorOnline_server_war_exploded/userController/acceptOperationKey", JSONObject.toJSONString(requestDto));
                        System.out.println(result);
                    }
                };
                thread.start();
            }
        });
        operationAdd = new JButton("+");
        operationAdd.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Thread thread = new Thread() {
                    @Override
                    public void run() {
                        requestDto.setKey(operationAdd.getText());
                        String result = HttpHelper.postHelper(path + "/CalculatorOnline_server_war_exploded/userController/acceptOperationKey", JSONObject.toJSONString(requestDto));
                        System.out.println(result);
                    }
                };
                thread.start();
            }
        });
        operationReduce = new JButton("-");
        operationReduce.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Thread thread = new Thread() {
                    @Override
                    public void run() {
                        requestDto.setKey(operationReduce.getText());
                        String result = HttpHelper.postHelper(path + "/CalculatorOnline_server_war_exploded/userController/acceptOperationKey", JSONObject.toJSONString(requestDto));
                        System.out.println(result);
                    }
                };
                thread.start();
            }
        });
        operationRide = new JButton("*");
        operationRide.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Thread thread = new Thread() {
                    @Override
                    public void run() {
                        requestDto.setKey(operationRide.getText());
                        String result = HttpHelper.postHelper(path + "/CalculatorOnline_server_war_exploded/userController/acceptOperationKey", JSONObject.toJSONString(requestDto));
                        System.out.println(result);
                    }
                };
                thread.start();
            }
        });
        operationExcept = new JButton("/");
        operationExcept.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Thread thread = new Thread() {
                    @Override
                    public void run() {
                        requestDto.setKey(operationExcept.getText());
                        String result = HttpHelper.postHelper(path + "/CalculatorOnline_server_war_exploded/userController/acceptOperationKey", JSONObject.toJSONString(requestDto));
                        System.out.println(result);
                    }
                };
                thread.start();
            }
        });
        spot = new JButton(".");
        spot.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Thread thread = new Thread() {
                    @Override
                    public void run() {
                        requestDto.setKey(spot.getText());
                        String result = HttpHelper.postHelper(path + "/CalculatorOnline_server_war_exploded/userController/acceptOperationKey", JSONObject.toJSONString(requestDto));
                        System.out.println(result);
                    }
                };
                thread.start();
            }
        });
        result = new JButton("=");
        result.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Thread thread = new Thread() {
                    @Override
                    public void run() {
                        requestDto.setKey(result.getText());
                        String result = HttpHelper.postHelper(path + "/CalculatorOnline_server_war_exploded/userController/acceptOperationKey", JSONObject.toJSONString(requestDto));
                        System.out.println(result);
                    }
                };
                thread.start();
            }
        });


        body = new JPanel(new GridLayout(4, 4, 3, 3));
        body.setBackground(Color.BLUE);
        body.add(num7);
        body.add(num8);
        body.add(num9);
        body.add(operationAdd);
        body.add(num4);
        body.add(num5);
        body.add(num6);
        body.add(operationReduce);
        body.add(num1);
        body.add(num2);
        body.add(num3);
        body.add(operationRide);
        body.add(spot);
        body.add(num0);
        body.add(result);
        body.add(operationExcept);

        GridLayout messageLayout = new GridLayout(3, 1, 3, 3);

        operationMessage = new JPanel(messageLayout);
        operationMessage.setBackground(Color.gray);


        data = new JTextArea();
        data.setEditable(false);
        data.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        data.setText("数据");

        temporaryData = new JTextArea();
        temporaryData.setEditable(false);
        temporaryData.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        temporaryData.setText("数据");


        res = new JTextArea();
        res.setEditable(false);
        res.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        res.setText("结果");

        operationMessage.add(data);
        operationMessage.add(temporaryData);
        operationMessage.add(res);

        logMessage = new JPanel(new BorderLayout(2, 2));
        logMessage.setBackground(Color.BLACK);

        logsStart = new JTextArea(1, 20);

        logs = new JTextArea();
        logsStart.setText("操作的信息：");
        logsStart.setEditable(false);
        logs.setText("操作的具体信息");

        logs.setLineWrap(true);

        jScrollPane = new JScrollPane(logs);
        logs.setBounds(100, 100, 100, 100);
        jScrollPane.setBounds(100, 100, 100, 100);
        jScrollPane.setHorizontalScrollBarPolicy(
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED
        );
        jScrollPane.setVerticalScrollBarPolicy(
                JScrollPane.VERTICAL_SCROLLBAR_ALWAYS
        );


        logMessage.add(logsStart, BorderLayout.NORTH);
        logMessage.add(jScrollPane);
    }


    public CalculatorOnlineBody(User user) {
        this.user=user;
        requestDto.setUser(user);

        this.setBounds(600, 300, 600, 540);
        this.setTitle("在线计算器");
        this.setBounds(600, 300, 600, 540);
        this.setResizable(false);
        this.invalidate(); // 保证组件是有效的布局
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // 实例化各组件
        Container con = this.getContentPane(); //生成一个容器
        BorderLayout window = new BorderLayout();
        window.setHgap(3);
        window.setVgap(3);
        con.setBackground(Color.cyan);
        con.setLayout(window);  //设置容器布局


        con.add(operationMessage, BorderLayout.NORTH);
        con.add(body, BorderLayout.CENTER);
        con.add(logMessage, BorderLayout.EAST);


        this.setVisible(true);
    }

    public static void main(String[] args) {
        new Client().start();
        User user = new User();
        user.setUsername("444");
        user.setPassword("");
        new CalculatorOnlineBody(user);
    }
}
