package com.gui;

import java.awt.*;
import java.awt.event.*; //加入的事件包
import javax.swing.*;

public class jsq extends JFrame implements ActionListener {
    // 添加的变量
    private double arg = 0;
    private String op = "=";
    private boolean start = true;
    JTextField jtf = new JTextField(16);
    JButton[] jb = new JButton[19];
    String[] st = {"Backspace", "CE", "+", "7", "8", "9", "-", "4", "5", "6",
            "*", "1", "2", "3", "/", "0", "+/-", ".", "="};

    public jsq() {
        super("计算器");
        for (int i = 0; i < 19; i++) {
            jb[i] = new JButton(st[i]);
        }
        jtf.setEditable(false);
        jtf.setText("0.");
        jtf.setForeground(Color.BLUE);
        jtf.setBackground(Color.WHITE);
        jtf.setHorizontalAlignment(JTextField.RIGHT); // 文本显示在右边
        GridBagLayout layout = new GridBagLayout();
        getContentPane().setLayout(layout);
        addComponent(layout, jtf, 0, 0, 4, 1);
        addComponent(layout, jb[0], 1, 0, 2, 1);
        addComponent(layout, jb[1], 1, 2, 1, 1);
        addComponent(layout, jb[2], 1, 3, 1, 1);
        addComponent(layout, jb[3], 2, 0, 1, 1);
        addComponent(layout, jb[4], 2, 1, 1, 1);
        addComponent(layout, jb[5], 2, 2, 1, 1);
        addComponent(layout, jb[6], 2, 3, 1, 1);
        addComponent(layout, jb[7], 3, 0, 1, 1);
        addComponent(layout, jb[8], 3, 1, 1, 1);
        addComponent(layout, jb[9], 3, 2, 1, 1);
        addComponent(layout, jb[10], 3, 3, 1, 1);
        addComponent(layout, jb[11], 4, 0, 1, 1);
        addComponent(layout, jb[12], 4, 1, 1, 1);
        addComponent(layout, jb[13], 4, 2, 1, 1);
        addComponent(layout, jb[14], 4, 3, 1, 1);
        addComponent(layout, jb[15], 5, 0, 1, 1);
        addComponent(layout, jb[16], 5, 1, 1, 1);
        addComponent(layout, jb[17], 5, 2, 1, 1);
        addComponent(layout, jb[18], 5, 3, 1, 1);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // 可以关闭窗体
        this.setLocationRelativeTo(null);
        this.setSize(300, 300);
        this.setVisible(true);
        this.show();
        this.setResizable(false);
    }

    // 这是加入的代码{
    public void actionPerformed(ActionEvent e) {
        String s = e.getActionCommand();
        if ('0' <= s.charAt(0) && s.charAt(0) <= '9' || s.equals(".")) {
            if (start) {
                jtf.setText(s);
            } else {
                jtf.setText(jtf.getText() + s);
            }
            start = false;
        } else {
            if (!s.equals("+/-")) {
                if (s.equals("Backspace")) {
                    String str = jtf.getText();
                    if (str.length() > 0)
                        jtf.setText(str.substring(0, str.length() - 1));
                } else if (s.equals("CE")) {
                    jtf.setText("0");
                    start = true;
                }
// else
// op = s;
//
// }
                else {
                    calculate(Double.parseDouble(jtf.getText()));
// 调用calculate()方法
                    op = s;
                    start = true;
                }
            } else {
                if (start) {
                    jtf.setText("-0");
                }
//如果是负数
                else if (jtf.getText().indexOf("-") != -1)
//改变为正数,substring(1)——取"-"号后面的字符
                    jtf.setText(jtf.getText().substring(1));
//否则,改为负数
                else jtf.setText("-" + jtf.getText());
            }
        }
    } // actionPerformed()方法结束

    /**
     * 定义calculate()方法
     */
    public void calculate(double n) {
        if (op.equals("+")) {
            arg += n;
        } else if (op.equals("-")) {
            arg -= n;
        } else if (op.equals("*")) {
            arg *= n;
        } else if (op.equals("/")) {
            arg /= n;
        } else if (op.equals("=")) {
            arg = n;
        }
        jtf.setText(Double.toString(arg));
    }

    // }加入的代码到这结束
    private void addComponent(GridBagLayout layout, Component component,
                              int row, int col, int width, int height) {
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.fill = GridBagConstraints.BOTH;
        constraints.insets = new Insets(10, 2, 10, 2);
        constraints.weightx = 100;
        constraints.weighty = 100;
        constraints.gridx = col;
        constraints.gridy = row;
        constraints.gridwidth = width;
        constraints.gridheight = height;
        layout.setConstraints(component, constraints);
        if (component instanceof JButton)
            ((JButton) component).addActionListener(this);
        getContentPane().add(component);
    }

    public static void main(String[] args) {
        new jsq();
    }
}