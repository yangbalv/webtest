package com.gui;



import com.static_class.ReloadFile;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;


public class TestGUI {
    //    GUI主体
    public static JFrame jFrame;

    //    面板
    public static JPanel jPanel1, jPanel2, jPanel3;

    //    标签
    public static JLabel jLabel1, jLabel2;


    //    勾选框
    public static JCheckBox jCheckBox1, jCheckBox2;

    //    点选框
    public static JRadioButton jRadioButton1, jRadioButton2;


    //    单选框控制器（使用时将new一个然后将元素add进去就行）
    public static ButtonGroup buttonGroup;

    //    按钮
    public static JButton jButton1, jButton2;

    public static JTextField jTextField;

    public static JTextArea jTextArea1, jTextArea2, jTextArea3;

    public static JScrollPane jScrollPane;

    public static String path;


    public TestGUI() {
        jFrame = new JFrame("zy_work");

        jFrame.setSize(500, 500);
        jFrame.setLocation(100, 100);
        jFrame.setIconImage(new ImageIcon("src/main/resources/image/注册商标 - 大.png").getImage());
        jFrame.setLayout(new GridLayout(3, 1));
//选择数据的来源
        jPanel1 = new JPanel();
        jLabel1 = new JLabel("基因的来源：");
        jRadioButton1 = new JRadioButton("人类");

        jRadioButton1.setSelected(true);
        jRadioButton2 = new JRadioButton("老鼠");
        buttonGroup = new ButtonGroup();
        buttonGroup.add(jRadioButton1);
        buttonGroup.add(jRadioButton2);
        jPanel1.add(jLabel1);
        jPanel1.add(jRadioButton1);
        jPanel1.add(jRadioButton2);

        path = (String) ReloadFile.properties.get("init_path");

        jPanel2 = new JPanel();
        JPanel jPanel_temporary1 = new JPanel();
        jPanel_temporary1.setLayout(new FlowLayout());
        JPanel jPanel_temporary2 = new JPanel();
        jPanel_temporary2.setLayout(new FlowLayout());
        jPanel2.setLayout(new GridLayout(2, 1));
        jTextField = new JTextField(40);
        jTextArea1 = new JTextArea(1, 4);
        jTextArea1.setEditable(false);
        jTextArea1.setText("文件夹:");
        jTextArea2 = new JTextArea(1, 35);
        jTextArea2.setLineWrap(true);
        jButton1 = new JButton("选择文件夹");
        jButton1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                System.out.println("path is : " + path);
                JFileChooser addChooser = new JFileChooser(path);
                addChooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
                //该方法设置为true允许选择多个文件
                int returnval = addChooser.showOpenDialog(jFrame);
                if (returnval == JFileChooser.APPROVE_OPTION) {
                    File file = addChooser.getSelectedFile();

                    jTextArea2.setText(file.getPath());
                    path = file.getPath();
                }
            }
        });
        jPanel_temporary1.add(jTextArea1);
        jPanel_temporary1.add(jTextArea2);
        jPanel_temporary2.add(jButton1);
        jPanel2.add(jPanel_temporary1);
        jPanel2.add(jPanel_temporary2);


        jPanel3 = new JPanel();
        jPanel3.setLayout(new GridLayout(2, 1));
        JPanel jPanel_temporary3 = new JPanel();
        jPanel_temporary3.setLayout(new FlowLayout());
        jButton2 = new JButton("提交");

        jTextArea3 = new JTextArea();
        jScrollPane = new JScrollPane(jTextArea3);
        jTextArea3.setBounds(100, 100, 100, 100);
        jScrollPane.setBounds(100, 100, 100, 100);
        jScrollPane.setHorizontalScrollBarPolicy(
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED
        );
        jScrollPane.setVerticalScrollBarPolicy(
                JScrollPane.VERTICAL_SCROLLBAR_ALWAYS
        );

//设置自动换行
        jTextArea3.setLineWrap(true);

        jButton2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                jTextArea3.setText("");
                System.out.println("*************");
                System.out.println("*************" + jTextArea2.getText());


                System.out.println("!!!!!!!!!!!!!!!!!");


            }
        });

        jPanel_temporary3.add(jButton2);

//        jPanel3.add(jTextArea3);
        jPanel3.add(jScrollPane);
        jPanel3.add(jPanel_temporary3);


        jFrame.add(jPanel1);
        jFrame.add(jPanel2);

        jFrame.add(jPanel3);
        jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jFrame.setVisible(true);
    }


    public static void main(String[] args) {
        new TestGUI();
    }
}
