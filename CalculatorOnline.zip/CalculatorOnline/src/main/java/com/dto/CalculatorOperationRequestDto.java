package com.dto;

import com.entity.User;

import java.util.Date;

public class CalculatorOperationRequestDto {
    private User user;
    private Date date;
    private String key;


    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }


    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }
}
