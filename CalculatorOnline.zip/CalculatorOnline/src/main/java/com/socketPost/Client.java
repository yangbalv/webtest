package com.socketPost;

import com.alibaba.fastjson.JSON;
import com.dto.SocketRemoteDto;
import com.gui.CalculatorOnlineBody;
import com.mysql.jdbc.StringUtils;
import com.static_class.ReloadFile;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;

public class Client extends Thread {


    @Override
    public void run() {

        try {

// 创建客户端得socket对象，连接的是本机所以ip地址为127.0.0.1

// 端口号为服务端的端口号


            int port = Integer.parseInt((String) ReloadFile.properties.get("server_port"));
            Socket client = new Socket((String) ReloadFile.properties.get("server_ip"), port);

            while (1 == 1) {

// 输出流

                OutputStream out = client.getOutputStream();

// DataOutputStream

                DataOutputStream dos = new DataOutputStream(out);

// dos执行写的操作

//dos.writeUTF("hello");

//用户从控制台输入

//                Scanner scanner = new Scanner(System.in);

                dos.writeUTF("scanner.nextLine()");

//客户端接收服务器端传递过来的字符串

                InputStream in = client.getInputStream();

//创建dataInputStream

                DataInputStream dis = new DataInputStream(in);

//读取服务器传递过来的信息
                String result = dis.readUTF();
                System.out.println("客户端读取服务端传递过来的信息：" + result);
                SocketRemoteDto socketRemoteDto = JSON.toJavaObject(JSON.parseObject(result), SocketRemoteDto.class);
                if (!StringUtils.isNullOrEmpty(socketRemoteDto.getAllMessage())) {
                    CalculatorOnlineBody.logs.setText(socketRemoteDto.getAllMessage());
                } else if (!StringUtils.isNullOrEmpty(socketRemoteDto.getMessage())) {
                    CalculatorOnlineBody.logs.append("\n" + socketRemoteDto.getMessage());
                }

                if (!StringUtils.isNullOrEmpty(socketRemoteDto.getOperational())) {
                    CalculatorOnlineBody.temporaryData.setText(socketRemoteDto.getOperational());
                }
                if (!StringUtils.isNullOrEmpty(socketRemoteDto.getFinalOperational())) {
                    CalculatorOnlineBody.data.setText(socketRemoteDto.getFinalOperational());
                }
                if (!StringUtils.isNullOrEmpty(socketRemoteDto.getResult())) {
                    CalculatorOnlineBody.res.setText(socketRemoteDto.getResult());
                }

            }

        } catch (UnknownHostException e) {

// TODO Auto-generated catch block

            e.printStackTrace();

        } catch (IOException e) {

// TODO Auto-generated catch block

            e.printStackTrace();

        }

    }

    public static void main(String[] args) {
        new Client().start();
    }
}